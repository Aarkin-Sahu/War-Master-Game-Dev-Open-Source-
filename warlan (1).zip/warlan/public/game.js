// Client: renders server state and sends commands. No game logic here.

const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
const hud = document.getElementById('hud');

const COLORS = ['#3b82f6', '#ef4444']; // player 0 blue, player 1 red
const NEUTRAL = '#9ca3af';
const R = 28; // building radius

let me = -1;
let state = null;
let clockOffset = 0;      // serverNow - clientNow
let selected = null;      // building id
let fraction = 0.5;

const ws = new WebSocket(`ws://${location.host}`);

ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.t === 'welcome') {
    me = m.you;
  } else if (m.t === 'state') {
    clockOffset = m.now - Date.now();
    state = m;
  }
};
ws.onclose = () => (hud.textContent = 'Disconnected from server.');

function send(obj) {
  if (ws.readyState === 1) ws.send(JSON.stringify(obj));
}

// ---------- Input ----------
function worldPos(ev) {
  const r = canvas.getBoundingClientRect();
  const p = ev.touches ? ev.touches[0] : ev;
  return {
    x: ((p.clientX - r.left) / r.width) * canvas.width,
    y: ((p.clientY - r.top) / r.height) * canvas.height,
  };
}

function buildingAt(p) {
  if (!state) return null;
  for (const b of state.buildings) {
    if (Math.hypot(b.x - p.x, b.y - p.y) <= R + 6) return b;
  }
  return null;
}

canvas.addEventListener('pointerdown', (ev) => {
  if (!state || me === -1) return;
  const b = buildingAt(worldPos(ev));
  if (!b) {
    selected = null;
    return;
  }
  if (selected === null) {
    if (b.owner === me) selected = b.id;
  } else if (b.id === selected) {
    selected = null;
  } else {
    send({ t: 'send', from: selected, to: b.id, fraction });
    selected = null;
  }
});

window.addEventListener('keydown', (ev) => {
  if (ev.key === '1') fraction = 0.25;
  if (ev.key === '2') fraction = 0.5;
  if (ev.key === '3') fraction = 0.75;
  if (ev.key === '4') fraction = 1;
  if (ev.key === 'Escape') selected = null;
  if (ev.key === 'r' && state && state.winner !== null) send({ t: 'restart' });
});

// ---------- Drawing ----------
function colorOf(owner) {
  return owner === -1 ? NEUTRAL : COLORS[owner];
}

function drawBuilding(b) {
  ctx.beginPath();
  ctx.arc(b.x, b.y, R, 0, Math.PI * 2);
  ctx.fillStyle = colorOf(b.owner);
  ctx.fill();
  ctx.lineWidth = b.id === selected ? 6 : 3;
  ctx.strokeStyle = b.id === selected ? '#ffd54a' : '#1f2937';
  ctx.stroke();

  ctx.fillStyle = '#fff';
  ctx.font = 'bold 22px system-ui';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(b.troops, b.x, b.y);
}

function drawGroup(g, serverNow) {
  const from = state.buildings[g.from];
  const to = state.buildings[g.to];
  const t = Math.min(1, Math.max(0, (serverNow - g.launch) / (g.arrive - g.launch)));
  const x = from.x + (to.x - from.x) * t;
  const y = from.y + (to.y - from.y) * t;

  // faint path line
  ctx.beginPath();
  ctx.moveTo(from.x, from.y);
  ctx.lineTo(to.x, to.y);
  ctx.strokeStyle = 'rgba(255,255,255,.12)';
  ctx.lineWidth = 2;
  ctx.setLineDash([6, 8]);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.beginPath();
  ctx.arc(x, y, 13, 0, Math.PI * 2);
  ctx.fillStyle = colorOf(g.owner);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = '#fff';
  ctx.stroke();
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 13px system-ui';
  ctx.fillText(g.count, x, y);
}

function frame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (state) {
    const serverNow = Date.now() + clockOffset;
    for (const g of state.groups) drawGroup(g, serverNow);
    for (const b of state.buildings) drawBuilding(b);

    if (state.winner !== null) {
      ctx.fillStyle = 'rgba(0,0,0,.55)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 56px system-ui';
      const msg = me === -1 ? `Player ${state.winner + 1} wins` : state.winner === me ? 'You win!' : 'You lose';
      ctx.fillText(msg, canvas.width / 2, canvas.height / 2 - 20);
      ctx.font = '24px system-ui';
      ctx.fillText('Press R to play again', canvas.width / 2, canvas.height / 2 + 35);
    }

    const role = me === -1 ? 'Spectating' : `You are <b style="color:${COLORS[me]}">${me === 0 ? 'Blue' : 'Red'}</b>`;
    const opp = state.players.every(Boolean) ? '' : ' &middot; waiting for second player...';
    hud.innerHTML = `${role}${opp} &middot; click your building, then a target &middot; send <b>${fraction * 100}%</b> (keys 1-4)`;
  }
  requestAnimationFrame(frame);
}
frame();
